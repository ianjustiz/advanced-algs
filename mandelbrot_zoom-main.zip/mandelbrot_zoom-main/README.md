# mandelbrot_zoom
Mandelbrot_zoom is an interactive Mandelbrot fractal generator. 

It provides support for rendering static frames or animations of the Mandelbrot set, in addition to a dynamically zoomable mode with dynamic input.

Current Features:
 - WIP

Documentation:
 - WIP
